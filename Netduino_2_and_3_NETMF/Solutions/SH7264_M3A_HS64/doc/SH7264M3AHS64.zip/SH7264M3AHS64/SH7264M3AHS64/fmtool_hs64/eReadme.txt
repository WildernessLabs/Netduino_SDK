Flash Memory Download Function Setting

 Loading flash memory		: "Enable"
 Erasing flash memory		: "Enable"
 File name			�F"C:\WorkSpace\XXXX\fmtool_hs64\sh7264_hs64_fmtool.mot"*
 Bus width of flash memory	: 16-bit bus width 
 Flash memory erasing time	: D'3
 Entry Point
-All erasing module address	: H'FFF81000
-Writing module address	�FH'FFF80000
-Access size			: 1 or 2

* The directory path in which the flash memory download program (fmtool_hs64.mot) is stored
  should be specified.