Flash Memory Download Function Setting

 Loading flash memory		: "Enable"
 Erasing flash memory		: "Enable"
 File name					: "$(PROJDIR)\FMTool\fmtool.mot"
 Bus width of flash memory	: 32-bit bus width
 Flash memory erasing time	: D'1
 
 Entry Point
-All erasing module address	: H'FFF80000 
-Writing module address		: H'FFF81100
-Access size				: 4
